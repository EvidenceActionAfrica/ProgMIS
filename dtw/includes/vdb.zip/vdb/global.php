<?php 

	include "db_conf.php";
	include "db_class.php";
	
	

 

 ?>